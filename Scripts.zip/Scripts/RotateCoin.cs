using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateCoin : MonoBehaviour
{
    // Start is called before the first frame update
    
    public GameObject coin;
    public float roatatespeed; 
    // Update is called once per frame
    public void OnMouseDown() 
    {
       coin.transform.Rotate(0f, roatatespeed, 0f);
    }
        
    }
