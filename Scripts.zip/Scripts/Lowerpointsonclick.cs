using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Lowerpointsonclick : MonoBehaviour
{
public int points;
public Text Scorea;
//public text and intergers to be changed on click
public void OnMouseDown() { 
    points -- ;
}
//on mouse down increase int by +1
public void Update() 
{ Scorea.text = points.ToString();
    
}
//displays int as text
}

//jrw
