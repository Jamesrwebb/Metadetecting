﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARSubsystems;
using UnityEngine.XR.ARFoundation;
using UnityEngine.UI;

[System.Serializable]
public class MarkerPrefabs
{
    public Texture marker;
    public GameObject targetPrefab;
}

[RequireComponent(typeof(ARTrackedImageManager))]
public class ARObjOverlayImage : MonoBehaviour
{
    private ARTrackedImageManager myTrackedImageManager;

    public MarkerPrefabs[] markerPrefabCombos;

    //store our MarkerPrefabs items in a dictionnary as these will be easier to retrieve
    private Dictionary<string, MarkerPrefabs> itemDictionary = new Dictionary<string, MarkerPrefabs>();

    void Awake()
    {
        myTrackedImageManager = GetComponent<ARTrackedImageManager>();

        //store our MarkerPrefabs items in a dictionnary as these will be easier to retrieve
        foreach (MarkerPrefabs item in markerPrefabCombos)
        {
            //use the name of the image as key later
            itemDictionary.Add(item.marker.name, item);
        }

        //Debug.Log("Dictionary size = " + itemDictionary.Count);
    }

    void OnEnable()
    {
        myTrackedImageManager.trackedImagesChanged += OnImageChanged;
        //Debug.Log("Enable");
    }

    void OnDisable()
    {
        myTrackedImageManager.trackedImagesChanged -= OnImageChanged;
        //Debug.Log("Disable");
    }

    private void OnImageChanged(ARTrackedImagesChangedEventArgs eventArgs)
    {
        foreach (ARTrackedImage trackedImage in eventArgs.added)
        {
            //Update the tracked image and overlaid object
            //Debug.Log(trackedImage.referenceImage.name + " is being added");

            UpdateTrackedImage(trackedImage);
        }

        foreach (ARTrackedImage trackedImage in eventArgs.updated)
        {
            /* If an image is properly tracked */
            //Debug.Log(trackedImage.referenceImage.name + " is being updated");

            UpdateTrackedImage(trackedImage);
        }

        foreach (ARTrackedImage trackedImage in eventArgs.removed)
        {
            //Update the tracked image and overlaid object
            Debug.Log(trackedImage.referenceImage.name + " is being removed");

            //Search for the overlaid object and disable it
            itemDictionary[name].targetPrefab.SetActive(false);
        }

    }

    private void UpdateTrackedImage(ARTrackedImage trackedImage)
    {
        string name = trackedImage.referenceImage.name;

        itemDictionary[name].targetPrefab.SetActive(true);
        //Ensure that the prefabs is a child of an empty GameObject which is positioned at the origin
        itemDictionary[name].targetPrefab.transform.position = trackedImage.transform.position;
        itemDictionary[name].targetPrefab.transform.rotation = trackedImage.transform.rotation;// * Quaternion.Euler(0.0f,180.0f,0.0f); //The last Quaternion multiplicator is used in the scene of the Mask robot to reverse the orientation of the prefab.

    }


}

 
