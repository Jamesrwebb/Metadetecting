﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

public class AROverlayOnPlane : MonoBehaviour
{
    [SerializeField] GameObject myPrefab;
    [SerializeField] ARSessionOrigin myARSessionOrigin;

    ARRaycastManager myARRaycastManager;

    static List<ARRaycastHit> hits = new List<ARRaycastHit>();

    private int hitCount;

    void Start()
    {
        myARRaycastManager = myARSessionOrigin.GetComponent<ARRaycastManager>();
    }

    void Update()
    {
        if(Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0); // Just get the first touch

            if (myARRaycastManager.Raycast(touch.position, hits, TrackableType.PlaneWithinPolygon))
            {
                //Only happens on first hit - no replication of object here
                if (hitCount == 0)
                {
                    Pose hitPose = hits[0].pose; // There can be multiple hits (potentially overlapping planes) -- just get the top-most
                    GameObject myOverlayObj = Instantiate(myPrefab, hitPose.position, hitPose.rotation);
                }
                hitCount += 1;
            }
        }
    }
}
